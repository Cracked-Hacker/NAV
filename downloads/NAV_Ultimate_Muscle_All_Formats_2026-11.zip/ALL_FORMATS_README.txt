NAV ULTIMATE MUSCLE CARD SET — ALL-FORMATS BUNDLE
Original material: Coach Nate | 379 cards

This bundle contains the original 379 text cards, preserved in multiple formats.
It has not been separately scientifically corrected or externally peer reviewed.

Contents:
- NAV_Muscle_Cards_Offline.html : offline web-browser reveal mode
- NAV_Muscle_Cards.csv : 379 cards (front/back), import or edit
- NAV_Muscle_Cards_Anki.tsv : 379 Anki-import rows, with GUIDs
- NAV_Ultimate_Muscle_Card_Set.apkg : native Anki deck, 379 notes / 379 cards
- NAV_Muscle_Cards_Print.pdf : 190-page duplex-print cards, four cards/sheet
- NAV_Classroom_Muscle_Cards.json : 379 original cards with stable identifiers
- READ_ME.txt : original export notes

Anki: On your computer, open Anki and choose File > Import, then the .apkg file.
PDF: Print at actual size, duplex, long-edge flip. Test pages 1-2 before printing all 190.
Offline HTML: open locally in a web browser; no account is needed.
Images from the original online Quizlet deck are NOT included in these offline text exports.
Original Quizlet: https://quizlet.com/1128248509/ultimate-muscle-card-set-flash-cards/

Owner's intended public offer: $0–$100 pay what you can; one complete bundle at every amount.
This local copy is a download artifact, NOT proof that a payment or website delivery flow is live.
Always verify a Venmo recipient in Venmo before any voluntary payment.
