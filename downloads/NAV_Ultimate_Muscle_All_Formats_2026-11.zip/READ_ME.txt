NAV Ultimate Muscle Card Set / 379 cards by Coach Nate

Offline HTML: open in a browser. Reveal answers individually.
CSV: Front and Back fields, original order, with multiline answers in quoted fields.
Print PDF: 95 duplex sheets (190 PDF pages), four cards per sheet. Use US Letter, actual size, and flip on long edge. Test pages 1-2 first.
Anki: import the TSV in Anki Desktop using File > Import. Use the Basic note type and NAV::Ultimate Muscle Card Set deck. Enable HTML and confirm the GUID column so repeated fronts remain distinct. Verify that Anki reports 379 notes.
Classroom JSON: stable IDs and verbatim front/back text for the NAV Classroom integration.
Quizlet: https://quizlet.com/1128248509/ultimate-muscle-card-set-flash-cards/?i=6z87ei&x=1jqt

The source exports supply text. Any images in the online deck are accessible through the Quizlet link.
